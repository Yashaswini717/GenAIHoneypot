#!/usr/bin/env python3
"""
Honeypot Session Log Parser
Converts a session_<id>.log into a clean structured JSON report.
Usage: python3 parse_session.py logs/session_20260327_050819_303.log
"""

import sys
import json
import os
import re
from datetime import datetime


def strip_ansi(text):
    """Remove ANSI escape sequences."""
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub("", text)


def apply_backspaces(text):
    """Simulate backspace key presses to reconstruct what was actually typed."""
    result = []
    for ch in text:
        if ch == '\x7f' or ch == '\x08':  # DEL or BS
            if result:
                result.pop()
        else:
            result.append(ch)
    return ''.join(result)


def clean_line(line):
    """Strip ANSI, apply backspaces, remove control chars."""
    line = strip_ansi(line)
    line = apply_backspaces(line)
    line = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', line)
    return line.strip()


def extract_prompt_and_command(line):
    """
    Extract command from a line containing a shell prompt.
    Handles both:
      devuser@dev-server:~$ <command>
      root@dev-server:~# <command>
    Also strips terminal title escape prefix like '0;devuser@...'
    """
    # Strip terminal title prefix (e.g. "0;devuser@dev-server: ~")
    line = re.sub(r'^[\d;]*[a-zA-Z0-9@.\-: ~/]*?(?=\w+@\w)', '', line)

    # Match prompt and extract command after it
    match = re.search(r'[\w]+@[\w\-]+:[^\$#]*[\$#]\s+(.*)', line)
    if match:
        return match.group(1).strip()
    return None


def parse_session_log(filepath):
    if not os.path.exists(filepath):
        print(f"Error: file not found: {filepath}")
        sys.exit(1)

    filename = os.path.basename(filepath)

    # Parse session ID parts from filename
    match = re.match(r"session_(\d{8})_(\d{6})_(\d+)\.log", filename)
    if match:
        date_str = match.group(1)
        time_str = match.group(2)
        pid = match.group(3)
        session_start = datetime.strptime(date_str + time_str, "%Y%m%d%H%M%S").isoformat()
    else:
        session_start = "unknown"
        pid = "unknown"

    with open(filepath, "r", errors="replace") as f:
        raw_content = f.read()

    # Split into lines
    raw_lines = raw_content.splitlines()

    # Clean each line
    cleaned_lines = [clean_line(l) for l in raw_lines]
    cleaned_lines = [l for l in cleaned_lines if l]

    # Extract session end time from last line if present
    session_end = "unknown"
    for line in reversed(cleaned_lines):
        m = re.search(r'Script done on (.+?) \[', line)
        if m:
            try:
                session_end = datetime.fromisoformat(m.group(1).strip().replace("+00:00", "")).isoformat()
            except Exception:
                session_end = m.group(1).strip()
            break

    # Calculate duration
    duration_seconds = None
    if session_start != "unknown" and session_end != "unknown":
        try:
            t1 = datetime.fromisoformat(session_start.replace("+00:00", ""))
            t2 = datetime.fromisoformat(session_end.replace("+00:00", ""))
            duration_seconds = int((t2 - t1).total_seconds())
        except Exception:
            pass

    # Extract terminal info from first line
    terminal_info = {}
    for line in cleaned_lines[:3]:
        m = re.search(r'TERM="([^"]+)".*COLUMNS="(\d+)".*LINES="(\d+)"', line)
        if m:
            terminal_info = {
                "term": m.group(1),
                "columns": int(m.group(2)),
                "lines": int(m.group(3))
            }
            break

    # Extract commands
    commands = []
    for line in cleaned_lines:
        cmd = extract_prompt_and_command(line)
        if cmd and cmd not in ("exit", "logout", "") and not cmd.startswith(";"):
            commands.append(cmd)

    # Remove duplicates while preserving order
    seen = set()
    unique_commands = []
    for cmd in commands:
        if cmd not in seen:
            seen.add(cmd)
            unique_commands.append(cmd)

    # Determine attacker skill level heuristic
    dangerous_commands = ["cat /etc/shadow", "cat /etc/passwd", "wget", "curl",
                          "chmod", "ssh", "nc", "netcat", "python", "perl",
                          "base64", "nmap", "/bin/sh", "/bin/bash", "sudo"]
    flags = [c for c in commands if any(d in c for d in dangerous_commands)]

    if len(commands) == 0:
        skill = "unknown"
    elif len(commands) <= 3 and not flags:
        skill = "low — basic recon only"
    elif flags:
        skill = "medium — attempted privilege escalation or exfiltration"
    else:
        skill = "low — exploratory only"

    report = {
        "session_id":        filename.replace(".log", ""),
        "filename":          filename,
        "session_start":     session_start,
        "session_end":       session_end,
        "duration_seconds":  duration_seconds,
        "pid":               pid,
        "terminal":          terminal_info,
        "command_count":     len(commands),
        "unique_commands":   unique_commands,
        "all_commands":      commands,
        "dangerous_commands_detected": flags,
        "attacker_skill":    skill,
        "total_lines":       len(cleaned_lines),
        "raw_output":        cleaned_lines,
    }

    return report


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 parse_session.py <session_log_file>")
        sys.exit(1)

    filepath = sys.argv[1]
    report = parse_session_log(filepath)

    output_path = filepath.replace(".log", "_report.json")
    with open(output_path, "w") as f:
        json.dump(report, f, indent=2)

    print(f"✅ Report saved to: {output_path}")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
